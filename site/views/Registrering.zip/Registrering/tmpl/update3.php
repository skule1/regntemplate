<?php

echo 'test<br>';
?>