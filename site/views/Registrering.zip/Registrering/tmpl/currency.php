dgf
<form>
  <input id="amount" type="number" value="1" />
  <select id="primary" class="input"></select>
  <select id="secondary" class="input"></select>   
  <input id="btn-convert" type="button" value="Convert" />   
</form>
<p id="result" style="display:none;">
  <span id="txt-primary"></span>
  <span id="txt-secondary"></span>
</p>